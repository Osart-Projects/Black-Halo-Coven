# Black Halo Coven

**Version:** 1.0.4  
**Author:** Osart

Black Halo Coven is a Midline Starsector faction centered on Ascension, cybernetic self-perfection, and the belief that humanity should master technology rather than fear it.

## Thanks

Special thanks to **Alex for creating Starsector** and making the game that this mod was built for.

Credits to **Vexlia Artemiss, Aris and kirb0o0** for creating Luminarch ship patterns for the mod.

## License

You may use, copy, modify, redistribute, repackage, adapt, or incorporate any original element of this mod however you wish, in private or public projects, commercial or noncommercial, with or without attribution. No permission from Osart is required. This permission applies to material in the mod to the extent that Osart has the right to license it; Starsector and third-party material remain subject to their respective owners and licenses.

## Dependencies

Black Halo Coven currently requires **Nexerelin** and **MagicLib**.

## MagicBounty Targets

Version 1.0.2 added ten high-difficulty, combat-only MagicBounty targets using Black Halo Coven fleets and dedicated 128x128 commander portraits. Target flagships use on-demand MagicBounty variants with permanent S-mod integrations.

## Additional Fleet Variants

Patch 1.0.2 added one additional no-S-mod, full-OP variant for each of the six Black Halo Coven hulls: Pursuit, Barrage, Scalpel, Bastion, Judgement, and Storm.

## RC8 Description Fix

Authored descriptions cover every fixed Black Halo celestial body in Empyrean and Narthex. Custom world descriptions use the correct `CUSTOM` description type and are finalized after the new-game economy is loaded.

## 1.0.3 Fix

Fixed the Seraph hull definition so its internal hull ID and sprite path match the Black Halo Seraph, and synchronized the Seraph and Ascendant Codex descriptions with their current mount layouts.

## 1.0.4 Major Update

- **Completely reworked the Acolyte.** The frigate received a new sprite and a full redesign of the ship itself: four Small Missile mounts, one Small Universal mount, one Medium Synergy mount, and the **Plasma Jets** ship system.
- Added the **Pilgrim Heavy Fighter**.
- Added the **Missionary Torpedo Bomber**.
- Added the new **Halo Missile** family as finite-ammunition Energy torpedoes:
  - **Halo Missile (Single)**
  - **Halo Missile Rack**
  - **Halo SRM Pod**
- The **Halo SRM Pod** is a medium missile launcher with 12 missiles, firing two per salvo, a 9-second firing cycle, 1200 range, and a 10 OP cost.
- Reworked the Pilgrim loadout and balance for its current heavy-fighter role.
- Added the **Black Halo Coven Blueprint Package**, unlocking Coven hulls, fighter LPCs, and proprietary weapons tagged with `black_halo_bp`.
- Added Black Halo Coven blueprint tags to the appropriate ships, fighters, and weapons.
- Added **Version Checker** support.
- Added Black Halo Coven faction music to fleet encounters as well as faction markets.
- Increased all **Luminarch** base prices to **45,000 credits**.
- Increased the **Ascendant** base price to **270,000 credits**.
- Fixed the Acolyte Vanguard variant ID so the variant is registered correctly.
- Removed the broad vanilla `missile_bp` pool from Coven faction stock and explicitly preserved approved missile systems, preventing Hammer-family launchers from appearing as legitimate Black Halo equipment.
- Removed redundant Java source files from the release package; the compiled JAR remains the single runtime code source, avoiding duplicate script-compilation warnings.
