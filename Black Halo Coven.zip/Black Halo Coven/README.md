# Black Halo Coven

**Version:** 1.0.6
**Author:** Osart

Black Halo Coven is a Midline Starsector faction centered on Ascension, cybernetic self-perfection, and the belief that humanity should master technology rather than fear it.

## Thanks

Special thanks to **Alex for creating Starsector** and making the game that this mod was built for.

Credits to **Vexlia Artemiss, Aris and kirb0o0** for creating Luminarch ship patterns for the mod.

## License

You may use, copy, modify, redistribute, repackage, adapt, or incorporate any original element of this mod however you wish, in private or public projects, commercial or noncommercial, with or without attribution. No permission from Osart is required. This permission applies to material in the mod to the extent that Osart has the right to license it; Starsector and third-party material remain subject to their respective owners and licenses.

## Dependencies

Black Halo Coven currently requires **Nexerelin** and **MagicLib**.

## MagicBounty Targets

Version 1.0.2 added ten high-difficulty, combat-only MagicBounty targets using Black Halo Coven fleets and dedicated 128x128 commander portraits. Target flagships use on-demand MagicBounty variants with permanent S-mod integrations.

## Additional Fleet Variants

Patch 1.0.2 added one additional no-S-mod, full-OP variant for each of the six Black Halo Coven hulls: Pursuit, Barrage, Scalpel, Bastion, Judgement, and Storm.

## RC8 Description Fix

Authored descriptions cover every fixed Black Halo celestial body in Empyrean and Narthex. Custom world descriptions use the correct `CUSTOM` description type and are finalized after the new-game economy is loaded.

## 1.0.3 Fix

Fixed the Seraph hull definition so its internal hull ID and sprite path match the Black Halo Seraph, and synchronized the Seraph and Ascendant Codex descriptions with their current mount layouts.

## 1.0.4 Fighter Update

Added the **Pilgrim Heavy Fighter**, a two-craft Black Halo Coven wing built around heavy armor, long engagement range, balanced ballistic guns, fighter-grade Swarmer missiles, Decoy Flares, and Insulated Engine Assembly.

## 1.0.5 Halo Missile & Pilgrim Revision

Removed the Halo Missile from the Pilgrim loadout and reduced its attack-run range so it closes properly into gun range. Pilgrim now relies on twin Light Autocannons, a Light Mortar, and a fighter-grade Swarmer SRM launcher, with a larger 400-point flux reserve. The **Halo Missile** is now a conventional finite-ammunition Energy torpedo with the same flight and 1000-damage profile as the Atropos. It is available as a one-round **Halo Missile (Single)** and a two-round **Halo Missile Rack**, using the same vanilla launcher art as the corresponding Atropos launchers.

## 1.0.6 Missionary, Pilgrim Rebalance & Blueprint Package

Added the **Missionary Torpedo Bomber**, matching the vanilla Trident's combat statistics, wing parameters, shield profile, mobility, and replacement time while replacing its two Atropos torpedoes with two **Halo Missile (Single)** launchers per bomber. Rebalanced the **Pilgrim Heavy Fighter** to a three-craft, 10 OP wing with 850 hull, 150 armor, 120 flux capacity, 40 dissipation, 190 speed, twin Light Dual Machine Guns, fighter-grade Swarmer SRMs, and Decoy Flares. Added the **Black Halo Coven Blueprint Package**, which teaches all hulls, fighter LPCs, and weapons tagged with `black_halo_bp`.
