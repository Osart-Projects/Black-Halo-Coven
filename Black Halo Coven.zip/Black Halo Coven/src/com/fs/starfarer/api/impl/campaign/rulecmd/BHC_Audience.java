package com.fs.starfarer.api.impl.campaign.rulecmd;

import blackhalo.BlackHaloPeople;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.OptionPanelAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.util.Misc;

import java.util.List;
import java.util.Map;

/** Vanilla-style gate to a single audience with the Black Halo faction leader. */
public class BHC_Audience extends BaseCommandPlugin {
    private static final String OPTION_REQUEST = "bhc_request_arch_seraph";
    private static final String OPTION_CONCLUDE = "bhc_audience_conclude";
    private static final float REQUIRED_RELATION = 1.0f; // exact maximum faction reputation

    @Override
    public boolean execute(String ruleId, InteractionDialogAPI dialog,
                           List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
        String mode = params == null || params.isEmpty() ? "" : params.get(0).getString(memoryMap);
        if ("is_liaison".equals(mode)) return isTalkingToLiaison(dialog);
        if ("configure".equals(mode)) return configureOption(dialog);
        if ("start".equals(mode)) return startAudience(dialog, memoryMap);
        if ("conclude".equals(mode)) return concludeAudience(dialog);
        return false;
    }

    private boolean isTalkingToLiaison(InteractionDialogAPI dialog) {
        PersonAPI person = getActivePerson(dialog);
        if (person == null || !BlackHaloPeople.LIAISON_ID.equals(person.getId())) return false;

        // Do not rely on the Comm Directory to retain the visual state for this
        // custom person. Re-assert both the portrait and the person visual every
        // time the liaison's dialogue options are populated. This also repairs
        // existing saves where the liaison object was created before the portrait
        // assignment was added.
        person.setPortraitSprite(
                "graphics/portraits/black halo coven/28_golden_halo_cyborg_bishop_captain.png");
        if (dialog.getVisualPanel() != null) {
            dialog.getVisualPanel().showPersonInfo(person, true);
        }

        MarketAPI capital = BlackHaloPeople.findCapital();
        MarketAPI current = getMarket(dialog);
        return capital != null && current == capital
                && BlackHaloPeople.FACTION_ID.equals(current.getFactionId());
    }

    /**
     * Keep the audience request visible and clickable at all reputation levels.
     * The tooltip carries the mechanical requirement, while clicking it produces
     * an in-character refusal until the player reaches maximum faction standing.
     */
    private boolean configureOption(InteractionDialogAPI dialog) {
        if (!isTalkingToLiaison(dialog) || dialog.getOptionPanel() == null) return false;
        OptionPanelAPI options = dialog.getOptionPanel();
        if (!options.hasOption(OPTION_REQUEST)) return true;

        boolean done = Global.getSector().getMemoryWithoutUpdate()
                .getBoolean(BlackHaloPeople.AUDIENCE_COMPLETE);
        if (done) {
            options.setOptionText("Request another audience with the Arch-Seraph", OPTION_REQUEST);
            options.setEnabled(OPTION_REQUEST, true);
            options.setTooltip(OPTION_REQUEST,
                    "You have already been received by the Arch-Seraph. Direct access is exceptional; the Inner Halo Legate now handles matters that do not require her personal attention.");
            return true;
        }

        float relation = getFactionRelation();
        int current = Math.round(relation * 100f);
        options.setEnabled(OPTION_REQUEST, true);
        if (relation < REQUIRED_RELATION) {
            options.setTooltip(OPTION_REQUEST,
                    "Requires 100/100 reputation with the Black Halo Coven. Current reputation: "
                            + current + "/100. You may submit the request, but the Inner Halo will decline it until your standing is absolute.");
        } else {
            options.setTooltip(OPTION_REQUEST,
                    "Your deeds have reached the Inner Halo. At 100/100 reputation, the Custodian is prepared to carry your request directly to the Arch-Seraph.");
        }
        return true;
    }

    private boolean startAudience(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        if (!isTalkingToLiaison(dialog)) return false;

        boolean done = Global.getSector().getMemoryWithoutUpdate()
                .getBoolean(BlackHaloPeople.AUDIENCE_COMPLETE);
        if (done) {
            String sibling = getSiblingWord();
            dialog.getTextPanel().addPara(
                    "The Custodian studies you for a moment, then gives a small shake of the head. \"You have already stood within the Inner Halo, "
                            + sibling + ". The Arch-Seraph does not grant audiences as a matter of routine. The legate appointed to you carries her attention in all lesser matters.\"");
            repopulateOptions(dialog, memoryMap);
            return true;
        }

        float relation = getFactionRelation();
        if (relation < REQUIRED_RELATION) {
            String sibling = getSiblingWord();
            dialog.getTextPanel().addPara(
                    "The Custodian receives the request without surprise and consults your record. After a few seconds, they look back to you. \"Your loyalty is known, "
                            + sibling + ", but the Inner Halo asks for more than loyalty. You have not yet proven yourself to the Coven beyond all doubt. When your deeds speak without qualification, the Arch-Seraph will hear your name.\"");
            repopulateOptions(dialog, memoryMap);
            return true;
        }

        PersonAPI leader = BlackHaloPeople.ensureLeader();
        if (leader == null) return false;

        dialog.getVisualPanel().saveCurrentVisual();
        dialog.getVisualPanel().showPersonInfo(leader, true);
        dialog.getOptionPanel().clearOptions();

        String sibling = getSiblingWord();
        dialog.getTextPanel().addPara(
                "The connection changes. Layers of authentication vanish from the display one after another until a single figure remains: the Arch-Seraph of the Black Halo Coven.");
        dialog.getTextPanel().addPara(
                "\"May you achieve perfection, " + sibling + ".\"");
        dialog.getTextPanel().addPara(
                "Her voice is calm rather than ceremonial. \"Most who seek the Inner Halo ask what the Coven can give them. Your record suggests a better question: what can you become? You have served, survived, adapted, and returned stronger. That is a language we understand.\"");

        Global.getSector().getMemoryWithoutUpdate()
                .set(BlackHaloPeople.AUDIENCE_COMPLETE, Boolean.TRUE);
        PersonAPI contact = BlackHaloPeople.unlockInnerHaloContact(dialog);

        if (contact != null) {
            dialog.getTextPanel().addPara(
                    "\"You may enter our inner circle, though not every matter requires my hand. "
                            + contact.getNameString()
                            + " will speak for the Inner Halo when your path intersects ours. Treat their word as carrying my attention.\"");
        }
        dialog.getTextPanel().addPara(
                "The audience is not an offer of rank or obedience. It is recognition: the Coven now considers your pursuit of improvement proven rather than merely professed.");

        dialog.getOptionPanel().addOption("Conclude the audience", OPTION_CONCLUDE);
        return true;
    }

    private void repopulateOptions(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        if (dialog == null || dialog.getOptionPanel() == null || memoryMap == null) return;
        // FireAll handles the vanilla PopulateOptions flow and clears/rebuilds the
        // option list itself.
        FireAll.fire(null, dialog, memoryMap, "PopulateOptions");
    }

    private boolean concludeAudience(InteractionDialogAPI dialog) {
        if (dialog == null) return false;
        dialog.getTextPanel().addPara(
                "\"May your next form surpass the last.\" The Arch-Seraph cuts the channel.");
        dialog.getVisualPanel().restoreSavedVisual();
        dialog.getOptionPanel().clearOptions();
        return true;
    }

    private float getFactionRelation() {
        FactionAPI faction = Global.getSector().getFaction(BlackHaloPeople.FACTION_ID);
        if (faction == null) return -1f;
        return faction.getRelationship("player");
    }

    private MarketAPI getMarket(InteractionDialogAPI dialog) {
        if (dialog == null) return null;
        SectorEntityToken target = dialog.getInteractionTarget();
        return target == null ? null : target.getMarket();
    }

    private PersonAPI getActivePerson(InteractionDialogAPI dialog) {
        if (dialog == null || dialog.getInteractionTarget() == null) return null;
        return dialog.getInteractionTarget().getActivePerson();
    }

    private String getSiblingWord() {
        PersonAPI player = Global.getSector().getPlayerPerson();
        if (player != null && player.getGender() == com.fs.starfarer.api.characters.FullName.Gender.FEMALE) {
            return "sister";
        }
        return "brother";
    }
}
