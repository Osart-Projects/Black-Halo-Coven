package blackhalo;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

import java.util.Random;

/**
 * Generates the compact authored Black Halo territory for the normal Sector.
 * Uses only the public Starsector campaign API: no reflection or file access.
 */
public final class BlackHaloWorldGen {
    public static final String FACTION_ID = "black_halo_coven";

    private static final String HEAVEN_MARKET = "bhc_elyon_market";
    private static final String CHOIR_MARKET = "bhc_choir_market";
    private static final String ASCENSION_MARKET = "bhc_ascension_market";

    private static final String ALPHA_CORE = "alpha_core";
    private static final String BETA_CORE = "beta_core";
    private static final String GAMMA_CORE = "gamma_core";

    private static final String CRYOARITHMETIC_ENGINE = "cryoarithmetic_engine";
    private static final String PRISTINE_NANOFORGE = "pristine_nanoforge";

    private BlackHaloWorldGen() {}

    public static void generate(SectorAPI sector) {
        if (sector == null) return;

        // Idempotent: protects against duplicate calls during new-game setup.
        if (sector.getStarSystem("Aurelia") != null || sector.getStarSystem("Empyrean") != null || sector.getStarSystem("Narthex") != null) {
            return;
        }

        createEmpyrean(sector);
        createNarthex(sector);
        setRelationships(sector);
    }

    private static void createEmpyrean(SectorAPI sector) {
        StarSystemAPI system = sector.createStarSystem("Empyrean");
        // Avoid Vector2f.set() binary-signature differences between bundled LWJGL builds.
        system.getLocation().x = 7600f;
        system.getLocation().y = -6800f;
        system.addTag("theme_core");

        PlanetAPI star = system.initStar("bhc_aurelia", "star_yellow", 520f, 500f);
        star.setCustomDescriptionId("bhc_aurelia");

        PlanetAPI elyon = system.addPlanet(
                "bhc_elyon", star, "Heaven", "terran",
                35f, 185f, 4300f, 210f);
        elyon.setCustomDescriptionId("bhc_elyon");
        MarketAPI heaven = createMarket(sector, elyon, HEAVEN_MARKET, "Heaven", 6,
                new String[]{
                        "population_6", "habitable", "mild_climate",
                        "farmland_adequate", "organics_plentiful", "ore_moderate", "rare_ore_sparse", "regional_capital"
                },
                new String[]{
                        "population", "megaport", "farming", "mining", "lightindustry", "commerce",
                        "starfortress_mid", "heavybatteries"
                }, true);
        configureHeaven(heaven);
        createFortressEntity(system, elyon, heaven,
                "bhc_heaven_fortress", "Heaven Star Fortress", "bhc_heaven_fortress_desc", 0f);

        PlanetAPI choir = system.addPlanet(
                "bhc_choir", elyon, "Choir", "barren",
                110f, 85f, 650f, 32f);
        choir.setCustomDescriptionId("bhc_choir");
        MarketAPI choirMarket = createMarket(sector, choir, CHOIR_MARKET, "Choir", 3,
                new String[]{
                        "population_3", "no_atmosphere", "low_gravity",
                        "ore_abundant", "rare_ore_sparse"
                },
                new String[]{
                        "population", "spaceport", "mining", "patrolhq",
                        "starfortress_mid", "heavybatteries"
                }, false);
        configureChoir(choirMarket);
        createFortressEntity(system, choir, choirMarket,
                "bhc_choir_fortress", "Choir Star Fortress", "bhc_choir_fortress_desc", 95f);

        PlanetAPI vesper = system.addPlanet(
                "bhc_vesper", star, "Vesper", "gas_giant",
                220f, 320f, 7600f, 390f);
        vesper.setCustomDescriptionId("bhc_vesper");

        system.autogenerateHyperspaceJumpPoints(true, true);
    }

    private static void createNarthex(SectorAPI sector) {
        StarSystemAPI system = sector.createStarSystem("Narthex");
        // Avoid Vector2f.set() binary-signature differences between bundled LWJGL builds.
        system.getLocation().x = 9950f;
        system.getLocation().y = -8100f;
        system.addTag("theme_core");

        PlanetAPI star = system.initStar("bhc_narthex", "star_orange", 430f, 450f);
        star.setCustomDescriptionId("bhc_narthex");

        PlanetAPI ascension = system.addPlanet(
                "bhc_ascension", star, "Ascension", "lava",
                70f, 165f, 3900f, 190f);
        ascension.setCustomDescriptionId("bhc_ascension");
        MarketAPI ascensionMarket = createMarket(sector, ascension, ASCENSION_MARKET, "Ascension", 5,
                new String[]{
                        "population_5", "very_hot", "extreme_tectonic_activity",
                        "ore_moderate", "rare_ore_sparse"
                },
                new String[]{
                        "population", "megaport", "refining", "orbitalworks", "highcommand",
                        "starfortress_mid", "heavybatteries"
                }, true);
        configureAscension(ascensionMarket);
        createFortressEntity(system, ascension, ascensionMarket,
                "bhc_ascension_fortress", "Ascension Star Fortress", "bhc_ascension_fortress_desc", 25f);

        PlanetAPI penitent = system.addPlanet(
                "bhc_penitent", star, "Penitent", "barren3",
                250f, 95f, 6400f, 310f);
        penitent.setCustomDescriptionId("bhc_penitent");

        system.autogenerateHyperspaceJumpPoints(true, true);
    }

    private static MarketAPI createMarket(
            SectorAPI sector,
            SectorEntityToken entity,
            String marketId,
            String marketName,
            int size,
            String[] conditions,
            String[] industries,
            boolean militarySubmarket) {

        MarketAPI market = Global.getFactory().createMarket(marketId, marketName, size);
        market.setFactionId(FACTION_ID);
        market.setPrimaryEntity(entity);
        market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
        market.setFreePort(false);

        for (String condition : conditions) {
            market.addCondition(condition);
        }
        for (String industry : industries) {
            market.addIndustry(industry);
        }

        market.addSubmarket("open_market");
        market.addSubmarket("black_market");
        market.addSubmarket("storage");
        if (militarySubmarket) {
            market.addSubmarket("generic_military");
        }

        entity.setMarket(market);
        entity.setFaction(FACTION_ID);

        market.reapplyConditions();
        market.reapplyIndustries();
        sector.getEconomy().addMarket(market, true);
        return market;
    }

    /**
     * Creates a named station token before the orbital-station industry advances.
     * The vanilla station industry adopts this connected entity and supplies the
     * actual Star Fortress fleet/visual, while we retain a faction-specific name
     * and description instead of the generic orbital-station text.
     */
    private static void createFortressEntity(
            StarSystemAPI system,
            PlanetAPI primary,
            MarketAPI market,
            String entityId,
            String name,
            String descriptionId,
            float angle) {

        SectorEntityToken station = system.addCustomEntity(
                entityId, name, "station_built_from_industry", FACTION_ID);
        station.setCircularOrbitWithSpin(
                primary, angle, primary.getRadius() + 190f,
                35f, 4f, 4f);
        station.setMarket(market);
        station.setCustomDescriptionId(descriptionId);
        station.setInteractionImage("illustrations", "orbital");
        station.addTag("use_station_visual");
        market.getConnectedEntities().add(station);
    }

    private static void configureHeaven(MarketAPI market) {
        if (market == null) return;

        // The capital uses AI selectively in key civic, industrial, and defensive systems.
        setCore(market, "starfortress_mid", ALPHA_CORE);
        setCore(market, "lightindustry", BETA_CORE);
        setCore(market, "mining", GAMMA_CORE);
        setCore(market, "commerce", GAMMA_CORE);
        setCore(market, "megaport", GAMMA_CORE);
        market.reapplyIndustries();
    }

    private static void configureChoir(MarketAPI market) {
        if (market == null) return;

        setCore(market, "mining", GAMMA_CORE);
        setCore(market, "patrolhq", BETA_CORE);
        setCore(market, "starfortress_mid", GAMMA_CORE);
        market.reapplyIndustries();
    }

    private static void configureAscension(MarketAPI market) {
        if (market == null) return;

        // Ascension is the Coven's deliberately harsh patrol-production world.
        // Extreme heat gives the Cryoarithmetic Engine its full +100% combat-fleet-size effect.
        setCore(market, "highcommand", BETA_CORE);
        setCore(market, "orbitalworks", BETA_CORE);
        setCore(market, "starfortress_mid", BETA_CORE);
        setCore(market, "refining", GAMMA_CORE);
        setCore(market, "heavybatteries", GAMMA_CORE);

        setSpecialItem(market, "highcommand", CRYOARITHMETIC_ENGINE);
        setSpecialItem(market, "orbitalworks", PRISTINE_NANOFORGE);
        market.reapplyIndustries();
    }

    private static void setCore(MarketAPI market, String industryId, String coreId) {
        Industry industry = market.getIndustry(industryId);
        if (industry != null) {
            industry.setAICoreId(coreId);
        }
    }

    private static void setSpecialItem(MarketAPI market, String industryId, String itemId) {
        Industry industry = market.getIndustry(industryId);
        if (industry != null) {
            industry.setSpecialItem(new SpecialItemData(itemId, null));
        }
    }

    /**
     * Finalizes authored description bindings after the new-game economy has loaded.
     * This method deliberately does not alter market size, conditions, industries,
     * planet type, AI cores, or special items. Existing campaigns are never passed
     * through this method by BlackHaloModPlugin.
     */
    public static void ensureDescriptions(SectorAPI sector) {
        if (sector == null) return;

        setDescription(sector, "bhc_aurelia");
        setDescription(sector, "bhc_elyon");
        setDescription(sector, "bhc_choir");
        setDescription(sector, "bhc_vesper");
        setDescription(sector, "bhc_narthex");
        setDescription(sector, "bhc_ascension");
        setDescription(sector, "bhc_penitent");

        setMarketStationDescription(sector, HEAVEN_MARKET,
                "Heaven Star Fortress", "bhc_heaven_fortress_desc");
        setMarketStationDescription(sector, CHOIR_MARKET,
                "Choir Star Fortress", "bhc_choir_fortress_desc");
        setMarketStationDescription(sector, ASCENSION_MARKET,
                "Ascension Star Fortress", "bhc_ascension_fortress_desc");
    }

    private static void setDescription(SectorAPI sector, String entityId) {
        SectorEntityToken entity = sector.getEntityById(entityId);
        if (entity != null) {
            entity.setCustomDescriptionId(entityId);
        }
    }

    private static void setMarketStationDescription(
            SectorAPI sector, String marketId, String stationName, String descriptionId) {
        if (sector.getEconomy() == null) return;
        MarketAPI market = sector.getEconomy().getMarket(marketId);
        if (market == null) return;

        for (SectorEntityToken entity : market.getConnectedEntities()) {
            if (entity != null && entity.hasTag("station")) {
                entity.setName(stationName);
                entity.setCustomDescriptionId(descriptionId);
                entity.setInteractionImage("illustrations", "orbital");
                entity.addTag("use_station_visual");
            }
        }
    }

    private static void setRelationships(SectorAPI sector) {
        setRelationship(sector, "independent", 0.50f);
        setRelationship(sector, "tritachyon", 0.40f);
        setRelationship(sector, "persean", 0.00f);
        setRelationship(sector, "hegemony", -0.40f);
        setRelationship(sector, "luddic_church", -0.75f);
        setRelationship(sector, "luddic_path", -1.00f);
        setRelationship(sector, "pirates", -0.50f);
        setRelationship(sector, "sindrian_diktat", 0.00f);
        setRelationship(sector, "player", 0.00f);
    }

    private static void setRelationship(SectorAPI sector, String otherId, float value) {
        FactionAPI ours = sector.getFaction(FACTION_ID);
        FactionAPI other = sector.getFaction(otherId);
        if (ours == null || other == null) return;

        ours.setRelationship(otherId, value);
        other.setRelationship(FACTION_ID, value);
    }
}
