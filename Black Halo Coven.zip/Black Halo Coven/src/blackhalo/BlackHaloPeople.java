package blackhalo;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.PersonImportance;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.contacts.ContactIntel;
import com.fs.starfarer.api.util.Misc;

import java.io.IOException;
import java.util.Random;

/**
 * Creates the small cast used by Black Halo's vanilla-style faction interactions.
 * The Arch-Seraph is deliberately not put in the comm directory; access is only
 * granted through the capital liaison. The Inner Halo Legate is a normal vanilla
 * contact, unlocked after the one-time audience.
 */
public final class BlackHaloPeople {
    public static final String FACTION_ID = BlackHaloWorldGen.FACTION_ID;

    public static final String LIAISON_ID = "bhc_inner_halo_liaison";
    public static final String LEADER_ID = "bhc_arch_seraph";
    public static final String CONTACT_ID = "bhc_inner_halo_contact";

    public static final String AUDIENCE_COMPLETE = "$bhc_arch_seraph_audience_complete";
    public static final String CONTACT_UNLOCKED = "$bhc_inner_halo_contact_unlocked";

    private static final String FIXED_CAPITAL_ID = "bhc_elyon_market";

    private static final String PORTRAIT_BASE = "graphics/portraits/black halo coven/";
    private static final String LEADER_PORTRAIT = PORTRAIT_BASE + "00_black_halo_coven_supreme.png";
    private static final String LIAISON_PORTRAIT = PORTRAIT_BASE + "28_golden_halo_cyborg_bishop_captain.png";
    private static final String CONTACT_PORTRAIT = PORTRAIT_BASE + "23_golden_halo_cybernetic_archdeacon.png";

    private static boolean reservedPortraitsLoaded = false;

    private BlackHaloPeople() {}

    private static void ensureReservedPortraitsLoaded() {
        if (reservedPortraitsLoaded) return;
        try {
            // These three portraits are intentionally reserved for unique NPCs and
            // therefore are not part of the faction's random portrait pools.
            // Explicit loading is required or the comm directory can render an
            // empty portrait even though PersonAPI points at a valid file.
            Global.getSettings().loadTexture(LEADER_PORTRAIT);
            Global.getSettings().loadTexture(LIAISON_PORTRAIT);
            Global.getSettings().loadTexture(CONTACT_PORTRAIT);
            reservedPortraitsLoaded = true;
        } catch (IOException ex) {
            throw new RuntimeException("Failed to load reserved Black Halo portraits", ex);
        }
    }

    public static void ensureSetup() {
        if (Global.getSector() == null || Global.getSector().getEconomy() == null) return;
        ensureReservedPortraitsLoaded();
        MarketAPI capital = findCapital();
        if (capital == null) return;

        FactionAPI faction = Global.getSector().getFaction(FACTION_ID);
        if (faction == null) return;

        ensureLeader(faction, capital);
        ensureLiaison(faction, capital);

        if (Global.getSector().getMemoryWithoutUpdate().getBoolean(AUDIENCE_COMPLETE)) {
            ensureInnerHaloContact(faction, capital, null);
        }
    }

    public static MarketAPI findCapital() {
        if (Global.getSector() == null || Global.getSector().getEconomy() == null) return null;

        MarketAPI fixed = Global.getSector().getEconomy().getMarket(FIXED_CAPITAL_ID);
        if (fixed != null && FACTION_ID.equals(fixed.getFactionId())) return fixed;

        FactionAPI faction = Global.getSector().getFaction(FACTION_ID);
        if (faction != null) {
            Object nexHq = faction.getMemoryWithoutUpdate().get("$nex_procgen_hq");
            if (nexHq instanceof MarketAPI) {
                MarketAPI hq = (MarketAPI) nexHq;
                if (FACTION_ID.equals(hq.getFactionId())) return hq;
            }
        }

        MarketAPI best = null;
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            if (!FACTION_ID.equals(market.getFactionId())) continue;
            if (best == null || market.getSize() > best.getSize()) best = market;
        }
        return best;
    }

    public static PersonAPI ensureLeader() {
        MarketAPI capital = findCapital();
        FactionAPI faction = Global.getSector() == null ? null : Global.getSector().getFaction(FACTION_ID);
        if (capital == null || faction == null) return null;
        return ensureLeader(faction, capital);
    }

    private static PersonAPI ensureLeader(FactionAPI faction, MarketAPI capital) {
        ImportantPeopleAPI people = Global.getSector().getImportantPeople();
        PersonAPI leader = people.getPerson(LEADER_ID);
        if (leader == null) {
            leader = faction.createRandomPerson(FullName.Gender.FEMALE);
            leader.setId(LEADER_ID);
            leader.setFaction(FACTION_ID);
            leader.setRankId("factionLeader");
            leader.setPostId("factionLeader");
            leader.setImportanceAndVoice(PersonImportance.VERY_HIGH,
                    new Random(seedFor(LEADER_ID)));
            leader.getName().setFirst("Aletheia");
            leader.getName().setLast("Voss");
            people.addPerson(leader);
        }
        leader.setPortraitSprite(LEADER_PORTRAIT);
        leader.setMarket(capital);
        return leader;
    }

    private static PersonAPI ensureLiaison(FactionAPI faction, MarketAPI capital) {
        ImportantPeopleAPI people = Global.getSector().getImportantPeople();
        PersonAPI liaison = people.getPerson(LIAISON_ID);
        if (liaison == null) {
            liaison = faction.createRandomPerson(FullName.Gender.FEMALE);
            liaison.setId(LIAISON_ID);
            liaison.setFaction(FACTION_ID);
            liaison.setRankId("innerHaloPrelate");
            liaison.setPostId("innerHaloLiaison");
            liaison.setImportanceAndVoice(PersonImportance.HIGH,
                    new Random(seedFor(LIAISON_ID)));
            people.addPerson(liaison);
        }
        liaison.setPortraitSprite(LIAISON_PORTRAIT);
        addPersonToMarket(liaison, capital, true);

        // Comm-directory entries can retain a stale cached visual on an existing
        // save even after the PersonAPI portrait is corrected. Rebuild just this
        // entry after setting the portrait so the directory immediately uses the
        // current sprite as well.
        if (capital.getCommDirectory() != null) {
            capital.getCommDirectory().removePerson(liaison);
            capital.getCommDirectory().addPerson(liaison);
        }
        return liaison;
    }

    /**
     * Unlocks a fully-developed, Very High importance vanilla contact.
     * The contact is intentionally not the Arch-Seraph herself.
     */
    public static PersonAPI unlockInnerHaloContact(InteractionDialogAPI dialog) {
        MarketAPI capital = findCapital();
        FactionAPI faction = Global.getSector() == null ? null : Global.getSector().getFaction(FACTION_ID);
        if (capital == null || faction == null) return null;
        return ensureInnerHaloContact(faction, capital, dialog);
    }

    private static PersonAPI ensureInnerHaloContact(
            FactionAPI faction, MarketAPI capital, InteractionDialogAPI dialog) {

        ImportantPeopleAPI people = Global.getSector().getImportantPeople();
        PersonAPI contact = people.getPerson(CONTACT_ID);
        if (contact == null) {
            contact = faction.createRandomPerson(FullName.Gender.MALE);
            contact.setId(CONTACT_ID);
            contact.setFaction(FACTION_ID);
            contact.setRankId("innerHaloPrelate");
            contact.setPostId("ascensionLegate");
            contact.setImportanceAndVoice(PersonImportance.VERY_HIGH,
                    new Random(seedFor(CONTACT_ID)));
            contact.addTag(Tags.CONTACT_MILITARY);
            contact.addTag(Tags.CONTACT_TRADE);
            contact.getRelToPlayer().setRel(0.25f);
            people.addPerson(contact);
        }

        contact.setPortraitSprite(CONTACT_PORTRAIT);

        // Use the vanilla contact lifecycle instead of manually creating a mission
        // hub or forcing the ContactIntel state. ContactIntel.develop() is the same
        // path used by normal developed contacts: it adds the person to the market
        // and comm directory, creates the vanilla BaseMissionHub, and clears any
        // suspended-contact flag. This keeps mission generation entirely vanilla.
        if (!ContactIntel.playerHasContact(contact, true)) {
            ContactIntel intel = new ContactIntel(contact, capital);
            intel.develop(null);
            TextPanelAPI text = dialog == null ? null : dialog.getTextPanel();
            Global.getSector().getIntelManager().addIntel(intel, dialog == null, text);
        }

        Global.getSector().getMemoryWithoutUpdate().set(CONTACT_UNLOCKED, Boolean.TRUE);
        return contact;
    }

    private static void addPersonToMarket(PersonAPI person, MarketAPI market, boolean commVisible) {
        if (person == null || market == null) return;
        // Vanilla helper also updates an existing ContactIntel and cleans up the old
        // market/comm-directory entry if the faction capital has moved.
        Misc.moveToMarket(person, market, commVisible);
    }

    private static long seedFor(String id) {
        String seed = Global.getSector() == null ? "black_halo" : Global.getSector().getSeedString();
        return (seed + ":" + id).hashCode();
    }
}
