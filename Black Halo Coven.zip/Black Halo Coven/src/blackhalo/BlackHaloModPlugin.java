package blackhalo;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

/** Main Black Halo Coven plugin. */
public class BlackHaloModPlugin extends BaseModPlugin {
    @Override
    public void onNewGame() {
        if (Global.getSector() == null) return;

        if (NexerelinSupport.shouldGenerateFixedSystems()) {
            BlackHaloWorldGen.generate(Global.getSector());
        }
    }

    @Override
    public void onNewGameAfterEconomyLoad() {
        BlackHaloWorldGen.ensureDescriptions(Global.getSector());
        BlackHaloPeople.ensureSetup();
    }

    @Override
    public void onGameLoad(boolean newGame) {
        // Intentionally empty. Existing campaigns are never rewritten on load.
    }
}
