package blackhalo;

import exerelin.campaign.ExerelinSetupData;
import exerelin.campaign.SectorManager;

import java.util.Map;

/** Nexerelin-specific setup bridge. No reflection is used. */
public final class NexerelinSupport {
    private static final String FACTION_ID = BlackHaloWorldGen.FACTION_ID;

    private NexerelinSupport() {}

    public static boolean shouldGenerateFixedSystems() {
        // In Nex random-sector mode, Nexerelin creates markets for enabled factions.
        if (!SectorManager.getManager().isCorvusMode()) return false;

        // Respect the faction enable/disable toggle on the Nex new-game screen.
        Map<String, Boolean> enabled = ExerelinSetupData.getInstance().factions;
        if (enabled == null) return true;
        Boolean state = enabled.get(FACTION_ID);
        return state == null || state.booleanValue();
    }
}
